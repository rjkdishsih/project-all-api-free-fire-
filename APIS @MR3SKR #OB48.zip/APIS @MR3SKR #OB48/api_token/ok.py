import asyncio
import aiohttp
import requests
import binascii
import time
import json
import random
import warnings
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor, as_completed

from flask import Flask, request, jsonify
from flask_caching import Cache

from Crypto.Cipher import AES
from Crypto.Util.Padding import pad

from colorama import init
# تهيئة colorama
init(autoreset=True)

# تجاهل تحذيرات شهادات SSL
from urllib3.exceptions import InsecureRequestWarning
warnings.filterwarnings("ignore", category=InsecureRequestWarning)

# استيراد ملفات البروتوباف والوظائف المساعدة من الملفات الخارجية
import uid_generator_pb2
import my_pb2
import output_pb2
from byte import *  # نفترض أن هذا الملف يوفر الدالتين Encrypt_ID وencrypt_api
from protobuf_parser import Parser, Utils

# استيراد المتغيرات السرية (المستخدمة في تشفير endpoint الإعجابات)
from secret import *  # يجب أن يحتوي على المتغيرين key و iv

app = Flask(__name__)
cache = Cache(app, config={'CACHE_TYPE': 'SimpleCache', 'CACHE_DEFAULT_TIMEOUT': 25200})  # مدة التخزين المؤقت 7 ساعات

# =====================================
# القسم الأول: إدارة المفاتيح وendpoint الإعجابات (/like)
# =====================================

# تخزين مفاتيح API
api_keys = set()
# تخزين وقت آخر إعجاب لكل UID
last_like_time = {}

def create_protobuf(saturn_, garena):
    message = uid_generator_pb2.uid_generator()
    message.saturn_ = saturn_
    message.garena = garena
    return message.SerializeToString()

def protobuf_to_hex(protobuf_data):
    return binascii.hexlify(protobuf_data).decode()

def encrypt_aes(hex_data, key_str, iv_str):
    # تحويل المفتاح والـ IV إلى بايتات بالطول المطلوب (16)
    key_bytes = key_str.encode()[:16]
    iv_bytes = iv_str.encode()[:16]
    cipher = AES.new(key_bytes, AES.MODE_CBC, iv_bytes)
    padded_data = pad(bytes.fromhex(hex_data), AES.block_size)
    encrypted_data = cipher.encrypt(padded_data)
    return binascii.hexlify(encrypted_data).decode()

# endpoints لإدارة المفاتيح
@app.route('/make_key', methods=['GET'])
def make_key():
    key_param = request.args.get('key')
    if not key_param:
        return jsonify({'error': 'Missing key parameter'}), 400
    api_keys.add(key_param)
    return jsonify({'message': 'Key added successfully', 'key': key_param}), 200

@app.route('/del_key', methods=['GET'])
def del_key():
    key_param = request.args.get('key')
    if not key_param:
        return jsonify({'error': 'Missing key parameter'}), 400
    if key_param in api_keys:
        api_keys.remove(key_param)
        return jsonify({'message': 'Key deleted successfully', 'key': key_param}), 200
    else:
        return jsonify({'error': 'Key not found'}), 404

@app.route('/del_all_keys', methods=['GET'])
def del_all_keys():
    api_keys.clear()
    return jsonify({'message': 'All keys deleted successfully'}), 200

@app.route('/all_keys', methods=['GET'])
def all_keys():
    return jsonify({'keys': list(api_keys)}), 200

def verify_key(key):
    return key in api_keys

# دوال مساعدة لendpoint /like
async def like(id_hex, session, token):
    like_url = 'https://clientbp.ggblueshark.com/LikeProfile'
    headers = {
        'X-Unity-Version': '2018.4.11f1',
        'ReleaseVersion': 'OB48',
        'Content-Type': 'application/x-www-form-urlencoded',
        'X-GA': 'v1 1',
        'Authorization': f'Bearer {token}',
        'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
        'Host': 'clientbp.ggblueshark.com',
        'Connection': 'Keep-Alive',
        'Accept-Encoding': 'gzip'
    }
    data = bytes.fromhex(id_hex)
    async with session.post(like_url, headers=headers, data=data) as response:
        status_code = response.status
        response_text = await response.text()
        return {'status_code': status_code, 'response_text': response_text}

async def get_account_info(uid, session):
    info_url = f'http://147.93.123.53:5002/{uid}'
    async with session.get(info_url) as response:
        if response.status == 200:
            return await response.json()
        else:
            return None

async def get_tokens(session):
    url = 'http://147.93.123.53:5003/token'
    async with session.get(url) as response:
        if response.status == 200:
            tokens = await response.json()
            token_list = tokens.get('tokens', [])
            return token_list[:100]
        else:
            return []

async def sendlike(uid, count=1):
    saturn_ = int(uid)
    garena = 1
    protobuf_data = create_protobuf(saturn_, garena)
    hex_data = protobuf_to_hex(protobuf_data)
    # استخدام المفتاح والـ IV من ملف secret لتشفير البيانات
    id_hex = encrypt_aes(hex_data, key, iv)
    start_time = time.time()
    current_time = datetime.now()
    async with aiohttp.ClientSession() as session:
        tokens = await get_tokens(session)
        if not tokens:
            return jsonify({"error": "No tokens available"}), 500
        account_info_before = await get_account_info(uid, session)
        if not account_info_before:
            return jsonify({"error": "Unable to fetch account info before sending likes"}), 500
        likes_before = account_info_before['basicinfo'][0]['likes']
        tasks = [like(id_hex, session, token) for token in tokens[:count]]
        results = await asyncio.gather(*tasks)
        account_info_after = await get_account_info(uid, session)
        if not account_info_after:
            return jsonify({"error": "Unable to fetch account info after sending likes"}), 500
        likes_after = account_info_after['basicinfo'][0]['likes']
        likes_added = likes_after - likes_before
        failed_likes = sum(1 for result in results if result['status_code'] != 200)
        last_like_time[uid] = current_time
        return jsonify({
            'uid': uid,
            'name': account_info_after['basicinfo'][0].get('username', 'Unknown'),
            'level': account_info_after['basicinfo'][0].get('level', 'N/A'),
            'likes_before': likes_before,
            'likes_after': likes_after,
            'likes_added': likes_added,
            'failed_likes': failed_likes,
            'region': account_info_after['basicinfo'][0].get('region', 'Unknown')
        }), 200

@app.route('/like', methods=['GET'])
def like_endpoint():
    try:
        uid = request.args.get('uid')
        api_key = request.args.get('key')
        count = int(request.args.get('count', 99))
        if not uid or not api_key:
            return jsonify({'error': 'Missing uid or key parameter'}), 400
        if not verify_key(api_key):
            return jsonify({'error': 'Invalid API key'}), 403
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop.run_until_complete(sendlike(uid, count))
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# =====================================
# القسم الثاني: endpoint الحصول على التوكنات (/token)
# =====================================

# المتغيرات الخاصة بتشفير endpoint التوكنات
TOKEN_AES_KEY = b'Yg&tc%DEuh6%Zc^8'
TOKEN_AES_IV = b'6oyZDr22E3ychjM%'

def get_token(password, uid):
    url = "https://ffmconnect.live.gop.garenanow.com/oauth/guest/token/grant"
    headers = {
        "Host": "100067.connect.garena.com",
        "User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)",
        "Content-Type": "application/x-www-form-urlencoded",
        "Accept-Encoding": "gzip, deflate, br",
        "Connection": "close"
    }
    data = {
        "uid": uid,
        "password": password,
        "response_type": "token",
        "client_type": "2",
        "client_secret": "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3",
        "client_id": "100067"
    }
    response = requests.post(url, headers=headers, data=data)
    if response.status_code != 200:
        return None
    return response.json()

def encrypt_message(key_bytes, iv_bytes, plaintext):
    cipher = AES.new(key_bytes, AES.MODE_CBC, iv_bytes)
    padded_message = pad(plaintext, AES.block_size)
    return cipher.encrypt(padded_message)

def load_tokens(file_path, limit=None):
    with open(file_path, 'r') as file:
        data = json.load(file)
        tokens = list(data.items())
        if limit is not None:
            tokens = tokens[:limit]
        return tokens

def parse_response(response_content):
    response_dict = {}
    lines = response_content.split("\n")
    for line in lines:
        if ":" in line:
            key_line, value_line = line.split(":", 1)
            response_dict[key_line.strip()] = value_line.strip().strip('"')
    return response_dict

def process_token(uid, password):
    token_data = get_token(password, uid)
    if not token_data:
        return {"uid": uid, "error": "Failed to retrieve token"}
    # إنشاء GameData Protobuf مع بيانات ثابتة
    game_data = my_pb2.GameData()
    game_data.timestamp = "2024-12-05 18:15:32"
    game_data.game_name = "free fire"
    game_data.game_version = 1
    game_data.version_code = "1.108.3"
    game_data.os_info = "Android OS 9 / API-28 (PI/rel.cjw.20220518.114133)"
    game_data.device_type = "Handheld"
    game_data.network_provider = "Verizon Wireless"
    game_data.connection_type = "WIFI"
    game_data.screen_width = 1280
    game_data.screen_height = 960
    game_data.dpi = "240"
    game_data.cpu_info = "ARMv7 VFPv3 NEON VMH | 2400 | 4"
    game_data.total_ram = 5951
    game_data.gpu_name = "Adreno (TM) 640"
    game_data.gpu_version = "OpenGL ES 3.0"
    game_data.user_id = "Google|74b585a9-0268-4ad3-8f36-ef41d2e53610"
    game_data.ip_address = "172.190.111.97"
    game_data.language = "en"
    game_data.open_id = token_data['open_id']
    game_data.access_token = token_data['access_token']
    game_data.platform_type = 4
    game_data.device_form_factor = "Handheld"
    game_data.device_model = "Asus ASUS_I005DA"
    game_data.field_60 = 32968
    game_data.field_61 = 29815
    game_data.field_62 = 2479
    game_data.field_63 = 914
    game_data.field_64 = 31213
    game_data.field_65 = 32968
    game_data.field_66 = 31213
    game_data.field_67 = 32968
    game_data.field_70 = 4
    game_data.field_73 = 2
    game_data.library_path = "/data/app/com.dts.freefireth-QPvBnTUhYWE-7DMZSOGdmA==/lib/arm"
    game_data.field_76 = 1
    game_data.apk_info = "5b892aaabd688e571f688053118a162b|/data/app/com.dts.freefireth-QPvBnTUhYWE-7DMZSOGdmA==/base.apk"
    game_data.field_78 = 6
    game_data.field_79 = 1
    game_data.os_architecture = "32"
    game_data.build_number = "2019117877"
    game_data.field_85 = 1
    game_data.graphics_backend = "OpenGLES2"
    game_data.max_texture_units = 16383
    game_data.rendering_api = 4
    game_data.encoded_field_89 = "\u0017T\u0011\u0017\u0002\b\u000eUMQ\bEZ\u0003@ZK;Z\u0002\u000eV\ri[QVi\u0003\ro\t\u0007e"
    game_data.field_92 = 9204
    game_data.marketplace = "3rd_party"
    game_data.encryption_key = "KqsHT2B4It60T/65PGR5PXwFxQkVjGNi+IMCK3CFBCBfrNpSUA1dZnjaT3HcYchlIFFL1ZJOg0cnulKCPGD3C3h1eFQ="
    game_data.total_storage = 111107
    game_data.field_97 = 1
    game_data.field_98 = 1
    game_data.field_99 = "4"
    game_data.field_100 = "4"
    serialized_data = game_data.SerializeToString()
    encrypted_data = encrypt_message(TOKEN_AES_KEY, TOKEN_AES_IV, serialized_data)
    hex_encrypted_data = binascii.hexlify(encrypted_data).decode('utf-8')
    url = "https://loginbp.common.ggbluefox.com/MajorLogin"
    headers = {
        'User-Agent': "Dalvik/2.1.0 (Linux; U; Android 9; ASUS_Z01QD Build/PI)",
        'Connection': "Keep-Alive",
        'Accept-Encoding': "gzip",
        'Content-Type': "application/octet-stream",
        'Expect': "100-continue",
        'X-Unity-Version': "2018.4.11f1",
        'X-GA': "v1 1",
        'ReleaseVersion': "OB48"
    }
    edata = bytes.fromhex(hex_encrypted_data)
    try:
        response = requests.post(url, data=edata, headers=headers, verify=False)
        if response.status_code == 200:
            example_msg = output_pb2.Garena_420()
            try:
                example_msg.ParseFromString(response.content)
                response_dict = parse_response(str(example_msg))
                return {"token": response_dict.get("token", "N/A")}
            except Exception as e:
                return {"uid": uid, "error": f"Failed to deserialize the response: {e}"}
        else:
            return {"uid": uid, "error": f"Failed to get response: HTTP {response.status_code}, {response.reason}"}
    except requests.RequestException as e:
        return {"uid": uid, "error": f"An error occurred while making the request: {e}"}

@app.route('/token', methods=['GET'])
@cache.cached(timeout=25200)
def get_responses():
    limit = request.args.get('limit', default=1, type=int)
    tokens = load_tokens("accs.txt", limit)
    responses = []
    with ThreadPoolExecutor(max_workers=15) as executor:
        future_to_uid = {executor.submit(process_token, uid, password): uid for uid, password in tokens}
        for future in as_completed(future_to_uid):
            try:
                response = future.result()
                responses.append(response)
            except Exception as e:
                responses.append({"uid": future_to_uid[future], "error": str(e)})
    return jsonify(responses)

# =====================================
# القسم الثالث: endpoint إرسال الزيارات (/visit/<uid>)
# =====================================

def fetch_tokens_for_visit():
    url = "http://147.93.123.53:5001/token"
    try:
        response = requests.get(url)
        if response.status_code == 200:
            tokens_data = response.json()
            if isinstance(tokens_data, dict) and "tokens" in tokens_data:
                tokens = tokens_data["tokens"]
            elif isinstance(tokens_data, list):
                tokens = []
                for item in tokens_data:
                    if isinstance(item, dict) and "tokens" in item:
                        tokens.extend(item["tokens"])
            else:
                tokens = []
            valid_tokens = [t for t in tokens if t and t != "N/A"][:4]
            return valid_tokens
        else:
            return []
    except Exception as e:
        return []

async def visit(session, token, uid, data):
    url = "https://clientbp.ggblueshark.com/GetPlayerPersonalShow"
    headers = {
        "ReleaseVersion": "OB48",
        "X-GA": "v1 1",
        "Authorization": f"Bearer {token}",
        "Host": "clientbp.ggblueshark.com"
    }
    try:
        async with session.post(url, headers=headers, data=data, ssl=False):
            pass
    except Exception:
        pass

async def send_requests_concurrently(tokens, uid, num_requests=300):
    connector = aiohttp.TCPConnector(limit=0)
    async with aiohttp.ClientSession(connector=connector) as session:
        # استخدام الدالتين encrypt_api وEncrypt_ID من ملف byte لتشفير البيانات
        data = bytes.fromhex(encrypt_api("08" + Encrypt_ID(uid) + "1801"))
        tasks = [asyncio.create_task(visit(session, tokens[i % len(tokens)], uid, data)) for i in range(num_requests)]
        await asyncio.gather(*tasks)

@app.route('/visit/<int:uid>', methods=['GET'])
def send_visits(uid):
    tokens = fetch_tokens_for_visit()
    if not tokens:
        return jsonify({"message": "⚠️ لم يتم العثور على أي توكن صالح"}), 500
    num_requests = 300
    asyncio.run(send_requests_concurrently(tokens, uid, num_requests))
    return jsonify({"message": f"✅ تم إرسال {num_requests} زائر إلى UID: {uid} باستخدام {len(tokens)} توكنات بسرعة عالية"}), 200

# =====================================
# تشغيل التطبيق
# =====================================
if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5008)