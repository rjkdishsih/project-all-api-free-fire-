import threading;import jwt;import random;import json;import requests;import google.protobuf;import datetime;from datetime import datetime;import base64;import logging;import re;import socket;import os;import binascii;import sys;import psutil;import time;from HelpDef import*;from time import sleep;from google.protobuf.timestamp_pb2 import Timestamp;from google.protobuf.json_format import MessageToJson;from protobuf_decoder.protobuf_decoder import Parser;from threading import Thread;from Crypto.Cipher import AES;from Crypto.Util.Padding import pad, unpad; import httpx;import urllib3; import MajorLoginRes_pb2
####################################
#FUCK SSL BY FOX
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
tempid = None
sent_inv = False
start_par = False
nameinv = "none"
idinv = 0
senthi = False
statusinfo = None
tempdata = None
data22 = None
####################################
paylod_token1 = "1a13323032352d30322d32362031343a30333a3237220966726565206669726528013a07312e3130392e334239416e64726f6964204f532039202f204150492d32382028504b51312e3138303930342e3030312f5631312e302e332e302e5045494d49584d294a0848616e6468656c64520d4d61726f632054656c65636f6d5a1243617272696572446174614e6574776f726b60dc0b68ee0572033333327a1d41524d3634204650204153494d4420414553207c2031383034207c203880019d1d8a010f416472656e6f2028544d29203530399201404f70656e474c20455320332e322056403333312e30202847495440636635376339632c204931636235633464316363292028446174653a30392f32332f3138299a012b476f6f676c657c34303663613862352d343633302d343062622d623535662d373834646264653262656365a2010d3130322e35322e3137362e3837aa0102656eb201206431616539613230633836633463303433666434616134373931313438616135ba010134c2010848616e6468656c64ca01135869616f6d69205265646d69204e6f74652035ea014030363538396138383431623331323064363962333138373737653939366236313838336631653162323463383263616365303439326231653761313631656133f00101ca020d4d61726f632054656c65636f6dd202023447ca03203734323862323533646566633136343031386336303461316562626665626466e003bd9203e803d772f003a017f803468004e7738804bd92039004e7739804bd9203c80401d2043f2f646174612f6170702f636f6d2e6474732e667265656669726574682d51614b46585768325f61717257642d434d58554d33673d3d2f6c69622f61726d3634e00401ea045f35623839326161616264363838653537316636383830353331313861313632627c2f646174612f6170702f636f6d2e6474732e667265656669726574682d51614b46585768325f61717257642d434d58554d33673d3d2f626173652e61706bf00403f804028a050236349a050a32303139313138303734a80503b205094f70656e474c455332b805ff7fc00504ca05094750174f05550b5135d20506416761646972da05023039e0059239ea0507616e64726f6964f2055c4b717348543376464d434e5a7a4f4966476c5a52584e657a3765646b576b5354546d6a446b6a3857313556676d44526c3257567a477a324f77342f42726259412f5a5a304e302b59416f4651477a5950744e6f51384835335534513df805fbe4068806019006019a060134a2060134"
paylod_token2 = '1a13323032352d30322d32362031343a30333a3237220966726565206669726528013a07312e3130392e334239416e64726f6964204f532039202f204150492d32382028504b51312e3138303930342e3030312f5631312e302e332e302e5045494d49584d294a0848616e6468656c64520d4d61726f632054656c65636f6d5a1243617272696572446174614e6574776f726b60dc0b68ee0572033333327a1d41524d3634204650204153494d4420414553207c2031383034207c203880019d1d8a010f416472656e6f2028544d29203530399201404f70656e474c20455320332e322056403333312e30202847495440636635376339632c204931636235633464316363292028446174653a30392f32332f3138299a012b476f6f676c657c34303663613862352d343633302d343062622d623535662d373834646264653262656365a2010d3130322e35322e3137362e3837aa0102656eb201206431616539613230633836633463303433666434616134373931313438616135ba010134c2010848616e6468656c64ca01135869616f6d69205265646d69204e6f74652035ea014030363538396138383431623331323064363962333138373737653939366236313838336631653162323463383263616365303439326231653761313631656133f00101ca020d4d61726f632054656c65636f6dd202023447ca03203734323862323533646566633136343031386336303461316562626665626466e003bd9203e803d772f003a017f803468004e7738804bd92039004e7739804bd9203c80401d2043f2f646174612f6170702f636f6d2e6474732e667265656669726574682d51614b46585768325f61717257642d434d58554d33673d3d2f6c69622f61726d3634e00401ea045f35623839326161616264363838653537316636383830353331313861313632627c2f646174612f6170702f636f6d2e6474732e667265656669726574682d51614b46585768325f61717257642d434d58554d33673d3d2f626173652e61706bf00403f804028a050236349a050a32303139313138303734a80503b205094f70656e474c455332b805ff7fc00504ca05094750174f05550b5135d20506416761646972da05023039e0059239ea0507616e64726f6964f2055c4b717348543376464d434e5a7a4f4966476c5a52584e657a3765646b576b5354546d6a446b6a3857313556676d44526c3257567a477a324f77342f42726259412f5a5a304e302b59416f4651477a5950744e6f51384835335534513df805fbe4068806019006019a060134a2060134'
freefire_version = "ob48"
client_secret = "2ee44819e9b4598845141067b281621874d0d5d7af9d8f7e00c1e54715b7d1e3"
chat_ip = "98.98.162.73"
chat_port = 39698
####################################
key = b'Yg&tc%DEuh6%Zc^8'
iv = b'6oyZDr22E3ychjM%' 
def parse_results(parsed_results):
    result_dict = {}
    for result in parsed_results:
        if result.wire_type == "varint":
            result_dict[int(result.field)] = result.data
        elif result.wire_type == "string" or result.wire_type == "bytes":
            result_dict[int(result.field)] = result.data
        elif result.wire_type == "length_delimited":
            nested_data = parse_results(result.data.results)
            result_dict[int(result.field)] = nested_data
    return result_dict
def zitado_get_proto(input_text):
    try:
        parsed_results = Parser().parse(input_text)
        parsed_results_objects = parsed_results
        parsed_results_dict = parse_results(parsed_results_objects)
        json_data = json.dumps(parsed_results_dict)
        return json_data
    except Exception as e:
        print(f"error {e}")
        return None
def gethashteam(hexxx):
    a = zitado_get_proto(hexxx)
    if not a:
        raise ValueError("Invalid hex format or empty response from zitado_get_proto")
    data = json.loads(a)
    return data['5']['7']
def getownteam(hexxx):
    a = zitado_get_proto(hexxx)
    if not a:
        raise ValueError("Invalid hex format or empty response from zitado_get_proto")
    data = json.loads(a)
    return data['5']['1']
####################################
#GET PLAYER STATUS
def get_player_status(packet):
    json_result = get_available_room(packet)
    parsed_data = json.loads(json_result)
    try:
        room_data = parsed_data["5"]["data"]
        data_room = room_data["1"]["data"]
        id_room = data_room['15']["data"]
    except:
            pass
    if "5" not in parsed_data or "data" not in parsed_data["5"]:
        return """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Offline

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM""" 
    json_data = parsed_data["5"]["data"]
    if "1" not in json_data or "data" not in json_data["1"]:
        return """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Offline

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM""" 
    data = json_data["1"]["data"]
    if "3" not in data:
        return """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Offline

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM""" 
    status_data = data["3"]
    if "data" not in status_data:
        return """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Offline

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM""" 
    status = status_data["data"]
    if status == 1:
        return """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Online
|--->Mode : Solo

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM""" 
    if status == 2:
        if "9" in data and "data" in data["9"]:
            group_count = data["9"]["data"]
            countmax1 = data["10"]["data"]
            countmax = countmax1 + 1
            return f"""
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Online
|--->Mode : IN SQUAD
|--->COUNT: ({group_count}/{countmax})

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM""" 
        return "INSQUAD"    
    if status in [3, 5]:
        return """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Online
|--->Mode : IN GAME

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM""" 
    if status == 4:
        return "IN ROOM"
    if status in [6, 7]:
        return """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Online
|--->Mode : IN SOCIAL ISLAND MODE

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM""" 
    return """
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
The player is Not in Data Base

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM"""
def Encrypt(number):
    number = int(number)
    encoded_bytes = []
    while True:
        byte = number & 0x7F
        number >>= 7
        if number:
            byte |= 0x80
        encoded_bytes.append(byte)
        if not number:
            break
    return bytes(encoded_bytes).hex()
#GET ROOM-ID BY PLAYER-ID
def get_idroom_by_idplayer(packet):
    json_result = get_available_room(packet)
    parsed_data = json.loads(json_result)
    json_data = parsed_data["5"]["data"]
    data = json_data["1"]["data"]
    idroom = data['15']["data"]
    return idroom    
    return "NOTFOUND"
####################################
def extract_jwt_from_hex(hex):
    byte_data = binascii.unhexlify(hex)
    message = Garena_420()
    message.ParseFromString(byte_data)
    json_output = MessageToJson(message)
    token_data = json.loads(json_output)
    return token_data
####################################
import psutil
def restart_program():
    p = psutil.Process(os.getpid())
    open_files = p.open_files()
    connections = psutil.net_connections()
    for handler in open_files:
        try:
            os.close(handler.fd)
        except Exception:
            pass            
    for conn in connections:
        try:
            conn.close()
        except Exception:
            pass
    sys.path.append(os.path.dirname(os.path.abspath(sys.argv[0])))
    python = sys.executable
    os.execl(python, python, *sys.argv)          
####################################
#CLIENT AND SERVER GARENA BY FOX
class FF_CLIENT(threading.Thread):
    def __init__(self, id, password):
        super().__init__()
        self.id = id
        self.password = password
        self.key = None
        self.iv = None
        self.get_tok()
    #DEF FOR PACKET FIELDS BY FOX
    def Packet_Fields(self, data):
        key, iv = self.key, self.iv
        try:
            key = key if isinstance(key, bytes) else bytes.fromhex(key)
            iv = iv if isinstance(iv, bytes) else bytes.fromhex(iv)
            data = bytes.fromhex(data)
            cipher = AES.new(key, AES.MODE_CBC, iv)
            cipher_text = cipher.encrypt(pad(data, AES.block_size))
            return cipher_text.hex()
        except Exception as e:
            pass
    #ALL PACKETS FIELDS BY FOX
    def GenResponsMsg(self, Msg, Enc_Id):
        return GenResponsMsg(Msg, Enc_Id, self.key, self.iv)    
    def accept_sq(self, hashteam, idplayer, ownerr):
        return accept_sq(hashteam, idplayer, ownerr, self.key, self.iv)    
    def send_squad(self, idplayer):
        return send_squad(idplayer, self.key, self.iv)    
    def invite_skwad(self, idplayer):
        return invite_skwad(idplayer, self.key, self.iv)    
    def skwad_maker(self):
        return skwad_maker(self.key, self.iv)    
    def changes(self, num):
        return changes(num, self.key, self.iv)    
    def leave_s(self):
        return leave_s(self.key, self.iv)
    def request_skwad(self, idplayer):
        return request_skwad(idplayer, self.key, self.iv)
    def start_autooo(self):
        return start_autooo(self.key, self.iv)
    #SPAM ROOM VIA UID
    def spam_room(self, idroom, idplayer, roomname):
        key, iv = self.key, self.iv
        fields = {
        1: 78,
        2: {
            1: int(idroom),
            2: roomname,
            4: 330,
            5: 6000,
            6: 330,
            10: int(get_random_avatar()),
            11: int(idplayer),
            12: 1
        }
        }
        packet = create_protobuf_packet(fields)
        packet = packet.hex()
        header_lenth = len(encrypt_packet(packet, key, iv)) // 2
        header_lenth_final = dec_to_hex(header_lenth)
        if len(header_lenth_final) == 2:
            final_packet = "0E15000000" + header_lenth_final + self.Packet_Fields(packet)
        elif len(header_lenth_final) == 3:
            final_packet = "0E1500000" + header_lenth_final + self.Packet_Fields(packet)
        elif len(header_lenth_final) == 4:
            final_packet = "0E150000" + header_lenth_final + self.Packet_Fields(packet)
        elif len(header_lenth_final) == 5:
            final_packet = "0E15000" + header_lenth_final + self.Packet_Fields(packet)
        return bytes.fromhex(final_packet)
    #CREATE PACKET INFO
    def PacketPlayerStatus(self, idddd):
        key, iv = self.key, self.iv
        ida = Encrypt(idddd)
        packet = f"080112090A05{ida}1005"
        header_lenth = len(encrypt_packet(packet, key, iv))//2
        header_lenth_final = dec_to_hex(header_lenth)
        if len(header_lenth_final) == 2:
            final_packet = "0F15000000" + header_lenth_final + self.Packet_Fields(packet)
        elif len(header_lenth_final) == 3:
            final_packet = "0F1500000" + header_lenth_final + self.Packet_Fields(packet)
        elif len(header_lenth_final) == 4:
            final_packet = "0F150000" + header_lenth_final + self.Packet_Fields(packet)
        elif len(header_lenth_final) == 5:
            final_packet = "0F15000" + header_lenth_final + self.Packet_Fields(packet)
        return bytes.fromhex(final_packet)

#GARENA SERVER BT FOX    
    def Server_garena(self, tok, host, port, packet, key, iv):
        global socket_client
        global sent_inv
        global tempid
        global start_par
        global clients
        global nameinv
        global idinv
        global senthi
        global statusinfo
        global tempdata
        global data22
        socket_client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        port = int(port)
        socket_client.connect((host,port))
        socket_client.send(bytes.fromhex(tok))
        while True:
            data2 = socket_client.recv(9999)
            #ENTER AUTO GAME PACKET BY FOX
            if "0500" in data2.hex()[0:4] and len(data2.hex()) > 30:
                if sent_inv == True:
                    accept_packet = f'08{data2.hex().split("08", 1)[1]}'
                    aa = gethashteam(accept_packet)
                    ownerid = getownteam(accept_packet)
                    print(ownerid)
                    print(aa)
                    ss = self.accept_sq(aa, tempid, int(ownerid))
                    socket_client.send(ss)
                    sleep(1)
                    startauto = self.start_autooo()
                    socket_client.send(startauto)
                    start_par = False
                    sent_inv = False
            if "0600" in data2.hex()[0:4] and len(data2.hex()) > 700:
                    accept_packet = f'08{data2.hex().split("08", 1)[1]}'
                    kk = get_available_room(accept_packet)
                    parsed_data = json.loads(kk)
                    print(parsed_data)
                    idinv = parsed_data["5"]["data"]["1"]["data"]
                    nameinv = parsed_data["5"]["data"]["3"]["data"]
                    senthi = True
            if "0f00" in data2.hex()[0:4]:
                packett = f'08{data2.hex().split("08", 1)[1]}'
                print(packett)
                kk = get_available_room(packett)
                parsed_data = json.loads(kk)
                idinv = parsed_data["1"]["data"]
                asdj = parsed_data["2"]["data"]
                if asdj == 15:
                    tempdata = get_player_status(packett)
                    if tempdata == "IN ROOM":
                        data22 = packett
                    print(data2.hex())
                    print(tempdata)
                    statusinfo = True
                else:
                    pass  
            if data2 == b"":
                restart_program()
                break
    #CLIENT BOT-FR BY FOX
    def Client_Garene(self, tok, host, port, packet, key, iv):
        global clients
        global socket_client
        global sent_inv
        global tempid
        global start_par
        global nameinv
        global idinv
        global senthi
        global statusinfo
        global tempdata
        global data22
        clients = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        port = int(port)
        clients.connect((host, port))
        clients.send(bytes.fromhex(tok))    
        thread = threading.Thread(
            target=self.Server_garena, args=(tok, chat_ip, chat_port, "anything", key, iv)
        )
        threads.append(thread)
        thread.start()   
        while True:
            data = clients.recv(9999)
##########BOT-FR-V1-BY-FOX#############
            #SHOW COMMANDS BOT-FR BY FOX
            if "1200" in data.hex()[0:4] and b"/help" in data:
                json_result = get_available_room(data.hex()[10:])
                parsed_data = json.loads(json_result)
                uid = parsed_data["5"]["data"]["1"]["data"]
                player_time_left = get_time(uid)
                clients.send(self.GenResponsMsg(player_time_left, uid))
                response_message = f"""
[11EAFD][b][c]BOT-FR V1: MENU 1
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°[FFB300][b][c]
-SEND SKWAD ID ->> COMMAND
-/ snd/[id]
-MAKE SKWAD 3 ->> COMMAND
-/ 3s
-MAKE SKWAD 4 ->> COMMAND
-/ 4s
-MAKE SKWAD 5 ->> COMMAND
-/ 5s
-MAKE SKWAD 6 ->> COMMAND
-/ 6s
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[11EAFD][b][c]BOT-FR V1: MENU 2
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°[FFB300][b][c]
-AUTO GAME ->> COMMAND
-/ come
-GET PLAYER ->> COMMAND
-/ inv/[id]
-Spam Join Skwad Via Id ->> COMMAND
-/ sm/[id]
-TEXT STYLE ->> COMMAND
-/ ms [text]
-SPAM ROOM ->> COMMANDE
-/ rm/[id]
-ID INFO ->> COMMAND
-/ info[id]
-PLAYER STATUS ->> COMMAND
-/ status/[id]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°"""
                time.sleep(1.5)
                clients.send(self.GenResponsMsg(response_message, uid))
                response_mssg = f"""
[11EAFD][b][c]BOT-FR V1: MENU 3
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°[FFB300][b][c]
-CHECK ID ->> COMMAND
-/ check/[id]
-GET ID REGION ->> COMMAND
-/ region/[id]
-CLAN INFO ->> COMMAND
-/ clan/[clan_id]
-INCRESS VISIT ->> COMMAND
-/ visit/[id]
-GET 100 LIKES ->> COMMAND
-/ likes/[id]
-CHAT WHIT AI ->> COMMAND
-/ ai [text]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[11EAFD][b][c]INSTAGRAM ADMIN USERNAMES :
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[B4FF69]FOX:
[FFC0CB]IG : [69FFB4]om1p9
[B4FF69]VOR[c]TEX[c]:
[FFC0CB]IG : [69FFB4]vor[c]tex[c].4x
[B4FF69]TRI[c]CK:
[FFC0CB]IG : [69FFB4]tri[c]ckz[c]qw
[B4FF69]L7AJ:
[FFC0CB]IG : [69FFB4]mx[c].fo{get_random_color()}
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFD700][c][b]CODEX TEAM THE BEST BOTS FOR FREE
"""
                time.sleep(1.5)
                clients.send(self.GenResponsMsg(response_mssg, uid))
            #SEND SKWAD 5 TO ID ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/snd/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        message_parts = message.split()
                        iddd = None
                        for part in message_parts:
                            if '/snd/' in part:
                                digits = ''.join(filter(str.isdigit, part.split('/snd/')[1]))
                                if digits:
                                    iddd = int(digits)
                                    break
                        if iddd is None:
                            iddd = 10414593349
                    except:
                        iddd = 10414593349
                    
                    packetfinal = self.changes(4)
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    packetmaker = self.skwad_maker()
                    socket_client.send(packetmaker)
                    sleep(1)
                    socket_client.send(packetfinal)
                    invitess = self.invite_skwad(iddd)
                    socket_client.send(invitess)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    iddd = fix_num(iddd)
                    clients.send(self.GenResponsMsg(f"""
            [11EAFD][b][c]
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            تم فتح سكواد 6 للاعب :
            {iddd}
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """,uid))
                    sleep(5)
                    leavee = self.leave_s()
                    socket_client.send(leavee)
                except Exception as e:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        uid = parsed_data["5"]["data"]["1"]["data"]
                        clients.send(self.GenResponsMsg("[FF0000][b]❗ حدث خطأ في العملية[/b]",uid))
                    except:
                        pass
####################################
            #MAKE SKWAD 3 ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/3s" in data:
                json_result = get_available_room(data.hex()[10:])
                parsed_data = json.loads(json_result)
                packetmaker = self.skwad_maker()
                socket_client.send(packetmaker)             
                sleep(1)
                packetfinal = self.changes(2)
                iddd=parsed_data["5"]["data"]["1"]["data"]
                print("\n\n")
                print(iddd)
                print("\n\n")
                socket_client.send(packetfinal)
                invitess = self.invite_skwad(iddd)
                socket_client.send(invitess)
                if iddd:
	                clients.send(
	                    self.GenResponsMsg(
	                        f"""
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
قبل طلب بسرعة!!!

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM
	                        """, iddd
	                    )
	                )
                sleep(5)
                leavee = self.leave_s()
                socket_client.send(leavee)   
            #MAKE SKWAD 4 ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/4s" in data:
                json_result = get_available_room(data.hex()[10:])
                parsed_data = json.loads(json_result)
                packetmaker = self.skwad_maker()
                socket_client.send(packetmaker)             
                sleep(1)
                packetfinal = self.changes(3)
                iddd=parsed_data["5"]["data"]["1"]["data"]
                socket_client.send(packetfinal)
                invitess = self.invite_skwad(iddd)
                socket_client.send(invitess)
                if iddd:
	                clients.send(
	                    self.GenResponsMsg(
	                        f"""
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
قبل طلب بسرعة!!!

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM
	                        """, iddd
	                    )
	                )
                sleep(5)
                leavee = self.leave_s()
                socket_client.send(leavee) 
            #MAKE SKWAD 5 ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/5s" in data:
                json_result = get_available_room(data.hex()[10:])
                parsed_data = json.loads(json_result)
                packetmaker = self.skwad_maker()
                socket_client.send(packetmaker)             
                sleep(1)
                packetfinal = self.changes(4)
                iddd=parsed_data["5"]["data"]["1"]["data"]
                socket_client.send(packetfinal)
                invitess = self.invite_skwad(iddd)
                socket_client.send(invitess)
                if iddd:
	                clients.send(
	                    self.GenResponsMsg(
	                        f"""
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
قبل طلب بسرعة!!!

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM
	                        """, iddd
	                    )
	                )
                sleep(5)
                leavee = self.leave_s()
                socket_client.send(leavee) 
            #MAKE SKWAD 6 ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/6s" in data:
                json_result = get_available_room(data.hex()[10:])
                parsed_data = json.loads(json_result)
                packetmaker = self.skwad_maker()
                socket_client.send(packetmaker)             
                sleep(1)
                packetfinal = self.changes(6)
                iddd=parsed_data["5"]["data"]["1"]["data"]
                socket_client.send(packetfinal)
                invitess = self.invite_skwad(iddd)
                socket_client.send(invitess)
                if iddd:
	                clients.send(
	                    self.GenResponsMsg(
	                        f"""
[11EAFD][b][c]
°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
قبل طلب بسرعة!!!

°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
[FFB300][b][c]BOT MADE BY CODEX TEAM
	                        """, iddd
	                    )
	                )
                sleep(5)
                leavee = self.leave_s()
                socket_client.send(leavee) 
####################################
            #SPAM ROOM ->> COMMANDE
            if "1200" in data.hex()[0:4] and b"/rm/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        parts = message.split('/rm/')[1].split('/')
                        player_id = parts[0].strip()
                        #roomname = parts[1].split()[0].strip() if len(parts) > 1 else "IG:om1p9"            
                        if not player_id.isdigit():
                            player_id = "10414593349"
                            roomname = "IG:om1p9"                
                        if "***" in player_id:
                            player_id = rrrrrrrrrrrrrr(player_id)                
                    except:
                        player_id = "10414593349"
                        roomname = "IG:om1p9"
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]        
                    packetmaker = self.PacketPlayerStatus(player_id)
                    socket_client.send(packetmaker)
                    sleep(1)        
                    if tempdata == "IN ROOM":
                        roomname = f"{get_random_color()}IG:om1p9"
                        room_id = get_idroom_by_idplayer(data22)
                        packetspam = self.spam_room(room_id, player_id, roomname)            
                        clients.send(self.GenResponsMsg(f"""
            [11EAFD][b][c]
            Spam Started for uid {fix_num(player_id)}!
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """, uid))
                        for _ in range(50):
                            for __ in range(5):
                                threading.Thread(target=socket_client.send, args=(packetspam,)).start()
                                time.sleep(0.0000002)            
                        clients.send(self.GenResponsMsg(f"""
            [11EAFD][b][c]
            Done Spam Sent!
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """, uid))
                    else:
                        clients.send(self.GenResponsMsg(f"""
            [11EAFD][b][c]
            The player is not in room
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """, uid))
                        
                except Exception as e:
                    restart_program() 

            #CHECK ID ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/check/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        player_id = message.split('/check/')[1].split()[0].strip()
                        if not player_id.isdigit():
                            player_id = "10414593349"
                    except:
                        player_id = "10414593349"
                    
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    clients.send(self.GenResponsMsg("Okay Sir, Please Wait..", uid))
                    
                    banned_status = check_banned_status(player_id)
                    player_id = fix_num(player_id)
                    status = banned_status['status']
                    response_message = f"""
            [11EAFD][b][c]
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            Player Name: {banned_status['player_name']}
            Player ID : {player_id}
            Status: {status}
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """
                    clients.send(self.GenResponsMsg(response_message, uid))
                except Exception as e:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        uid = parsed_data["5"]["data"]["1"]["data"]
                        clients.send(self.GenResponsMsg(f"[FF0000]Error: {str(e)}", uid))
                    except:
                        restart_program()
            #GET ID REGION ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/region/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        player_id = message.split('/region/')[1].split()[0].strip()
                        if not player_id.isdigit():
                            player_id = "10414593349"
                    except:
                        player_id = "10414593349"
                    
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    clients.send(self.GenResponsMsg("Okay Sir, Please Wait..", uid))
                    
                    b = get_player_info(player_id)
                    player_id = fix_num(player_id)
                    response_message = f"""
            [11EAFD][b][c]
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            Player Name : {b['Name']}
            Player ID : {player_id}
            Player Region : {b['Account Region']}
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """
                    clients.send(self.GenResponsMsg(response_message, uid))
                except Exception as e:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        uid = parsed_data["5"]["data"]["1"]["data"]
                        clients.send(self.GenResponsMsg(f"[FF0000]Error: {str(e)}", uid))
                    except:
                        restart_program()
            if "1200" in data.hex()[0:4] and b"/spm/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        player_id = message.split('/spm/')[1].split()[0].strip()
                        if not player_id.isdigit():
                            player_id = "10414593349"
                    except:
                        player_id = "10414593349"
                    
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    clients.send(self.GenResponsMsg("Okay Sir, Please Wait..", uid))
                    
                    b = spam_requests(player_id)
                    player_id = fix_num(player_id)
                    response_message = f"""
            [11EAFD][b][c]
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            Status : {fix_num(b)}
            Player ID : {player_id}
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """
                    clients.send(self.GenResponsMsg(response_message, uid))
                except Exception as e:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        uid = parsed_data["5"]["data"]["1"]["data"]
                        clients.send(self.GenResponsMsg(f"[FF0000]Error: {str(e)}", uid))
                    except:
                        restart_program()
            #CHAT WHIT AI ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/ai" in data:
	                json_result = get_available_room(data.hex()[10:])
	                parsed_data = json.loads(json_result)
	                uid = parsed_data["5"]["data"]["1"]["data"]
	                try:
	                    clients.send(self.GenResponsMsg(
    	                        f"Okay Sir, Please Wait..", uid
    	                    )
    	                )
	                    i = re.split("/ai", str(data))[1]
	                    if "***" in i:
	                        i = i.replace("***", "106")
	                    question = str(i).split("(\\x")[0].strip()
	                    ai_msg = talk_with_ai(question)
	                    clients.send(self.GenResponsMsg(ai_msg, uid))
	                except:
	                    restart_program()
            #CLAN INFO ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/clan/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        clan_id = message.split('/clan/')[1].split()[0].strip()
                        if not clan_id.isdigit():
                            clan_id = "3074343994"
                    except:
                        clan_id = "3074343994"
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    clients.send(self.GenResponsMsg("Okay Sir, Please Wait..", uid))
                    clan_info = Get_clan_info(clan_id)
                    clan_id = fix_num(clan_id)
                    clients.send(self.GenResponsMsg(clan_info, uid))
                except Exception as e:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        uid = parsed_data["5"]["data"]["1"]["data"]
                        clients.send(self.GenResponsMsg(f"[FF0000]Error: {str(e)}", uid))
                    except:
                        restart_program()
            #INCRESS VISIT ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/visit/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        player_id = message.split('/visit/')[1].split()[0].strip()
                        if not player_id.isdigit():
                            player_id = "10414593349"
                    except:
                        player_id = "10414593349"
                    
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    clients.send(self.GenResponsMsg("Okay Sir, Please Wait..", uid))
                    
                    inc_visit = increase_visits_threaded(player_id)
                    clients.send(self.GenResponsMsg(inc_visit, uid))
                except Exception as e:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        uid = parsed_data["5"]["data"]["1"]["data"]
                        clients.send(self.GenResponsMsg(f"[FF0000]Error: {str(e)}", uid))
                    except:
                        restart_program()
####################################
            #GET 100 LIKES ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/likes/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        player_id = message.split('/likes/')[1].split()[0].strip()
                        if not player_id.isdigit():
                            player_id = "10414593349"
                    except:
                        player_id = "10414593349"
                    
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    clients.send(self.GenResponsMsg("Okay Sir, Please Wait..", uid))
                    
                    likes_info = send_likes(player_id)
                    player_id = fix_num(player_id)
                    clients.send(self.GenResponsMsg(likes_info, uid))
                except Exception as e:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        uid = parsed_data["5"]["data"]["1"]["data"]
                        clients.send(self.GenResponsMsg(f"[FF0000]Error: {str(e)}", uid))
                    except:
                        restart_program()
###################################
            #ID INFO ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/info" in data:
                try:
                    command_split = re.split("/info", str(data))
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    clients.send(self.GenResponsMsg("Okay Sir, Please Wait..", uid))       
                    if len(command_split) > 1:
                        try:
                            player_id = command_split[1].split("\\x")[0].strip().split('(')[0].strip()
                            if not player_id or not player_id.isdigit():
                                raise ValueError("Invalid ID format")
                        except:
                            player_id = "10414593349"
                        try:
                            b = get_player_info(player_id)
                            if not b:
                                clients.send(self.GenResponsMsg(
                                    "[FF0000][b]❗ لم يتم العثور على معلومات اللاعب[/b]", 
                                    uid
                                ))
                                return
                            response_message = f"""
            [11EAFD][b][c]
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            Player Name : {b.get('Name', 'N/A')}
            Player ID : {fix_num(player_id)}
            Player Region : {b.get('Account Region', 'N/A')}
            Account Create : {fix_num(b.get('Account Create', 'N/A'))}
            Player Likes : {fix_num(b.get('Account Likes', 'N/A'))}
            Player Level : {b.get('Account Level', 'N/A')}
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            [FFB300][b][c]BOT MADE BY CODEX TEAM
                            """
                            print(response_message)
                            clients.send(self.GenResponsMsg(response_message, uid))               
                        except Exception as e:
                            pass
                            clients.send(self.GenResponsMsg(
                                "[FF0000][b]❗ حدث خطأ في جلب المعلومات[/b]", 
                                uid
                            ))                            
                except Exception as e:
                    restart_program()
####################################
            #AUTO GAME ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/come" in data:
                json_result = get_available_room(data.hex()[10:])
                parsed_data = json.loads(json_result)
                iddd = parsed_data["5"]["data"]["1"]["data"]
                clients.send(
                    self.GenResponsMsg(
                        f"[C][B][00ff00]اقبل البوت بسرعة!!!", iddd
                    )
                )
                tempid = iddd
                invskwad = self.request_skwad(iddd)
                socket_client.send(invskwad)
                sent_inv = True
                time.sleep(3)
                startauto = self.start_autooo()
                for _ in range(30):
                    socket_client.send(startauto)
                    time.sleep(0.01)
                time.sleep(20)
                leveee = self.leave_s()
                socket_client.send(leveee)
            #GET PLAYER ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/inv/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    parts = message.split('/inv/')[1].split()
                    iddd = parts[0].strip() if parts and parts[0].strip().isdigit() else "10414593349"
                    
                    if "***" in iddd:
                        iddd = iddd.replace("***", "106") 
                    numsc = 5 
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    
                    packetmaker = self.skwad_maker()
                    socket_client.send(packetmaker)
                    sleep(1)
                    packetfinal = self.changes(numsc)
                    socket_client.send(packetfinal)
                    invitess = self.invite_skwad(iddd)
                    socket_client.send(invitess)
                    invitessa = self.invite_skwad(uid)
                    socket_client.send(invitessa)
                    
                    clients.send(self.GenResponsMsg(f"""
            [11EAFD][b][c]
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            قبل طلب بسرعة!!!
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """, uid))
                    
                    sleep(9)
                    leavee = self.leave_s()
                    socket_client.send(leavee)
                except Exception as e:
                    try:
                        json_result = get_available_room(data.hex()[10:])
                        parsed_data = json.loads(json_result)
                        uid = parsed_data["5"]["data"]["1"]["data"]
                        clients.send(self.GenResponsMsg(f"[FF0000]Error: {str(e)}", uid))
                    except:
                        restart_program()
            #Spam Join Skwad Via Id ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/sm/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    try:
                        player_id = message.split('/sm/')[1].split()[0].strip()
                        if not player_id.isdigit():
                            player_id = "10414593349"
                        iddd = int(player_id)
                    except:
                        iddd = 10414593349
                    json_result = get_available_room(data.hex()[10:])
                    invskwad = self.request_skwad(iddd)
                    socket_client.send(invskwad)
                    parsed_data = json.loads(json_result)
                    for _ in range(30):
                        socket_client.send(invskwad)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    iddd = fix_num(iddd)
                    clients.send(self.GenResponsMsg(f"""
            [11EAFD][b][c]
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            تم بدأ السبام طلبات إنضمام للاعب:
            {iddd}
            °°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°°
            [FFB300][b][c]BOT MADE BY CODEX TEAM
            """, uid))
                    sleep(5)
                    leavee = self.leave_s()
                    socket_client.send(leavee)
                except Exception as e:
                    restart_program()
            #PLAYER STATUS ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/status/" in data:
                try:
                    message = data.decode('utf-8', errors='ignore')
                    player_id = message.split('/status/')[1].split()[0].strip()
                    if "***" in player_id:
                        player_id = player_id.replace("***", "106")
                    if not player_id.isdigit():
                        player_id = "10414593349"
                    json_result = get_available_room(data.hex()[10:])
                    parsed_data = json.loads(json_result)
                    uid = parsed_data["5"]["data"]["1"]["data"]
                    packetmaker = self.PacketPlayerStatus(player_id)
                    socket_client.send(packetmaker)
                    sleep(1)
                    if statusinfo == True:
                        clients.send(self.GenResponsMsg(f"[b][C][00FFFF]{tempdata}", uid))
                except Exception as e:
                    restart_program()
            #TEXT STYLE ->> COMMAND
            if "1200" in data.hex()[0:4] and b"/ms" in data:
                json_result = get_available_room(data.hex()[10:])
                parsed_data = json.loads(json_result)
                uid = parsed_data["5"]["data"]["1"]["data"]
                try:
                    decoded_data = data.decode('utf-8')
                except UnicodeDecodeError:
                    decoded_data = data.decode('latin-1')
                if "/ms " in decoded_data:
                    message = decoded_data.split("/ms ")[1]
                    message = message.split("\n")[0]
                    cleaned_message = re.sub(r'[^\x20-\x7E]', '', message)
                    unwanted_chars = ["(J,", "(J@"]
                    for char in unwanted_chars:
                        cleaned_message = cleaned_message.replace(char, "")
                    cleaned_message = " ".join(cleaned_message.split())
                    for i in range(1, len(cleaned_message) + 1):
                        partial_message = cleaned_message[:i]
                        clients.send(
                self.GenResponsMsg(                 f"""{get_random_color()}{partial_message}""", uid
                )
            )
                        time.sleep(0.2)
##########BOT-FR-V1-BY-FOX#############
    def parse_my_message(self, serialized_data):
        MajorLogRes = MajorLoginRes_pb2.MajorLoginRes()
        MajorLogRes.ParseFromString(serialized_data)       
        timestamp = MajorLogRes.kts
        key = MajorLogRes.ak
        iv = MajorLogRes.aiv
        BASE64_TOKEN = MajorLogRes.token
        timestamp_obj = Timestamp()
        timestamp_obj.FromNanoseconds(timestamp)
        timestamp_seconds = timestamp_obj.seconds
        timestamp_nanos = timestamp_obj.nanos
        combined_timestamp = timestamp_seconds * 1_000_000_000 + timestamp_nanos
        return combined_timestamp, key, iv, BASE64_TOKEN
    def GET_PAYLOAD_BY_DATA(self,JWT_TOKEN , NEW_ACCESS_TOKEN,date):
        global paylod_token1
        token_payload_base64 = JWT_TOKEN.split('.')[1]
        token_payload_base64 += '=' * ((4 - len(token_payload_base64) % 4) % 4)
        decoded_payload = base64.urlsafe_b64decode(token_payload_base64).decode('utf-8')
        decoded_payload = json.loads(decoded_payload)
        NEW_EXTERNAL_ID = decoded_payload['external_id']
        SIGNATURE_MD5 = decoded_payload['signature_md5']
        now = datetime.now()
        now =str(now)[:len(str(now))-7]
        formatted_time = date
        payload = bytes.fromhex(paylod_token1)
        payload = payload.replace(b"2024-12-26 13:02:43", str(now).encode())
        payload = payload.replace(b"88332848f415ca9ca98312edcd5fe8bc6547bc6d0477010a7feaf97e3435aa7f", NEW_ACCESS_TOKEN.encode("UTF-8"))
        payload = payload.replace(b"e1ccc10e70d823f950f9f4c337d7d20a", NEW_EXTERNAL_ID.encode("UTF-8"))
        payload = payload.replace(b"7428b253defc164018c604a1ebbfebdf", SIGNATURE_MD5.encode("UTF-8"))
        PAYLOAD = payload.hex()
        PAYLOAD = encrypt_api(PAYLOAD)
        PAYLOAD = bytes.fromhex(PAYLOAD)
        ip,port = self.GET_LOGIN_DATA(JWT_TOKEN , PAYLOAD)
        return ip,port    
    def dec_to_hex(ask):
        ask_result = hex(ask)
        final_result = str(ask_result)[2:]
        if len(final_result) == 1:
            final_result = "0" + final_result
            return final_result
        else:
            return final_result
    def convert_to_hex(PAYLOAD):
        hex_payload = ''.join([f'{byte:02x}' for byte in PAYLOAD])
        return hex_payload
    def convert_to_bytes(PAYLOAD):
        payload = bytes.fromhex(PAYLOAD)
        return payload
    def GET_LOGIN_DATA(self, JWT_TOKEN, PAYLOAD):
        global freefire_version
        url = "https://clientbp.common.ggbluefox.com/GetLoginData"
        headers = {
            'Expect': '100-continue',
            'Authorization': f'Bearer {JWT_TOKEN}',
            'X-Unity-Version': '2018.4.11f1',
            'X-GA': 'v1 1',
            'ReleaseVersion': freefire_version,
            'Content-Type': 'application/x-www-form-urlencoded',
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 9; G011A Build/PI)',
            'Host': 'clientbp.common.ggbluefox.com',
            'Connection': 'close',
            'Accept-Encoding': 'gzip, deflate, br',
        }        
        max_retries = 3
        attempt = 0
        while attempt < max_retries:
            try:
                response = requests.post(url, headers=headers, data=PAYLOAD,verify=False)
                response.raise_for_status()
                x = response.content.hex()
                json_result = get_available_room(x)
                parsed_data = json.loads(json_result)
                print(parsed_data)
                address = parsed_data['32']['data']
                ip = address[:len(address) - 6]
                port = address[len(address) - 5:]
                return ip, port            
            except requests.RequestException as e:
                pass
                attempt += 1
                time.sleep(2)
        pass
        return None, None
    def guest_token(self,uid , password):
        global client_secret
        url = "https://100067.connect.garena.com/oauth/guest/token/grant"
        headers = {"Host": "100067.connect.garena.com","User-Agent": "GarenaMSDK/4.0.19P4(G011A ;Android 9;en;US;)","Content-Type": "application/x-www-form-urlencoded","Accept-Encoding": "gzip, deflate, br","Connection": "close",}
        data = {"uid": f"{uid}","password": f"{password}","response_type": "token","client_type": "2","client_secret": client_secret,"client_id": "100067",}
        response = requests.post(url, headers=headers, data=data)
        data = response.json()
        NEW_ACCESS_TOKEN = data['access_token']
        NEW_OPEN_ID = data['open_id']
        OLD_ACCESS_TOKEN = "06589a8841b3120d69b318777e996b61883f1e1b24c82cace0492b1e7a161ea3"
        OLD_OPEN_ID = "d1ae9a20c86c4c043fd4aa4791148aa5"
        time.sleep(0.2)
        data = self.TOKEN_MAKER(OLD_ACCESS_TOKEN , NEW_ACCESS_TOKEN , OLD_OPEN_ID , NEW_OPEN_ID,uid)
        return(data)        
    def TOKEN_MAKER(self,OLD_ACCESS_TOKEN , NEW_ACCESS_TOKEN , OLD_OPEN_ID , NEW_OPEN_ID,id):
        global paylod_token2,freefire_version
        headers = {
            'X-Unity-Version': '2018.4.11f1',
            'ReleaseVersion': freefire_version,
            'Content-Type': 'application/x-www-form-urlencoded',
            'X-GA': 'v1 1',
            'Content-Length': '928',
            'User-Agent': 'Dalvik/2.1.0 (Linux; U; Android 7.1.2; ASUS_Z01QD Build/QKQ1.190825.002)',
            'Host': 'loginbp.common.ggbluefox.com',
            'Connection': 'Keep-Alive',
            'Accept-Encoding': 'gzip'
        }
        data = bytes.fromhex(paylod_token2)
        data = data.replace(OLD_OPEN_ID.encode(),NEW_OPEN_ID.encode())
        data = data.replace(OLD_ACCESS_TOKEN.encode() , NEW_ACCESS_TOKEN.encode())
        hex = data.hex()
        d = encrypt_api(data.hex())
        Final_Payload = bytes.fromhex(d)
        URL = "https://loginbp.ggblueshark.com/MajorLogin"
        RESPONSE = requests.post(URL, headers=headers, data=Final_Payload,verify=False)
        combined_timestamp, key, iv, BASE64_TOKEN = self.parse_my_message(RESPONSE.content)
        if RESPONSE.status_code == 200:
            if len(RESPONSE.text) < 10:
                return False
            ip,port =self.GET_PAYLOAD_BY_DATA(BASE64_TOKEN,NEW_ACCESS_TOKEN,1)
            self.key = key
            self.iv = iv
            return(BASE64_TOKEN,key,iv,combined_timestamp,ip,port)
        else:
            return False
    def time_to_seconds(hours, minutes, seconds):
        return (hours * 3600) + (minutes * 60) + seconds
    def seconds_to_hex(seconds):
        return format(seconds, '04x')    
    def extract_time_from_timestamp(timestamp):
        dt = datetime.fromtimestamp(timestamp)
        h = dt.hour
        m = dt.minute
        s = dt.second
        return h, m, s    
    def get_tok(self):
        global g_token
        token, key, iv, Timestamp, ip, port = self.guest_token(self.id, self.password)
        g_token = token
        print(ip, port)
        try:
            decoded = jwt.decode(token, options={"verify_signature": False})
            account_id = decoded.get('account_id')
            encoded_acc = hex(account_id)[2:]
            hex_value = dec_to_hex(Timestamp)
            time_hex = hex_value
            BASE64_TOKEN_ = token.encode().hex()
        except Exception as e:
            print(f"Error processing token: {e}")
            return
        try:
            head = hex(len(encrypt_packet(BASE64_TOKEN_, key, iv)) // 2)[2:]
            length = len(encoded_acc)
            zeros = '00000000'
            if length == 9:
                zeros = '0000000'
            elif length == 8:
                zeros = '00000000'
            elif length == 10:
                zeros = '000000'
            elif length == 7:
                zeros = '000000000'
            else:
                print('Unexpected length encountered')
            head = f'0115{zeros}{encoded_acc}{time_hex}00000{head}'
            final_token = head + encrypt_packet(BASE64_TOKEN_, key, iv)
        except Exception as e:
            print(f"Error constructing final token: {e}")
        token = final_token
        self.Client_Garene(token, ip, port, 'anything', key, iv)
        return token, key, iv       
with open('accs.txt', 'r') as file:
    data = json.load(file)
ids_passwords = list(data.items())
def run_client(id, password):
    print(f"ID: {id}, Password: {password}")
    client = FF_CLIENT(id, password)
    client.start()    
max_range = 300000
num_clients = len(ids_passwords)
num_threads = 1
start = 0
end = max_range
step = (end - start) // num_threads
threads = []
for i in range(num_threads):
    ids_for_thread = ids_passwords[i % num_clients]
    id, password = ids_for_thread
    thread = threading.Thread(target=run_client, args=(id, password))
    threads.append(thread)
    time.sleep(0.1)
    thread.start()
for thread in threads:
    thread.join()   
if __name__ == "__main__":
    try:
        client_thread = FF_CLIENT(id="3764548065", password="D1EBDA566F7F888D5662E8A4F30D318C4760492D605F9663A7A49DDA6AA84800")
        client_thread.start()
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        restart_program()
##########BOT-FR-V1-BY-FOX#############